<?= $this->include('template/header'); ?>
<section class="hero">
    <h1><?= $title; ?></h1>
    <hr>
    <p><?= $content; ?></p>
</section>
<?= $this->include('template/footer'); ?>