
# Praktikum 9: Framework Lanjutan (Modul Login)

**_Nama: Zaini Muhtarom_** <br/>
**_Nim : 312110294_** <br/>
**_Kelas : TI.21.A3_** <br/>

<br/>

## Login Page : 
<img src="img/login-page.png">
<img src="img/user-login.png">

## Artikel : 
<img src="img/artikel.png">

<br/>

## Detail Artikel : 
<img src="img/detail-artikel.png">

<br/>

## Admin Artikel : 
<img src="img/admin-artikel.png">

<br/>

## Admin Tambah Artikel : 
<img src="img/add-artikel.png">

<br/>

## Admin Edit Artikel : 
<img src="img/edit-artikel.png">

<br/>
